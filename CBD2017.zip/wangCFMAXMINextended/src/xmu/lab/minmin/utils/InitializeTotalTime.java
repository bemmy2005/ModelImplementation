package xmu.lab.minmin.utils;

import java.util.ArrayList;
import java.util.List;

public class InitializeTotalTime {
	public  static void initializeTotalTime(List<List<Double>> tasksResources, Double[] readyTime) {
		for(int i=0;i<tasksResources.size();i++){
			List<Double>temp=new ArrayList<Double>();
			for(int j=0;j<readyTime.length;j++){
				Double readTime=readyTime[j];
				Double currentCompletionTime=tasksResources.get(i).get(j);
				currentCompletionTime+=readTime;
				temp.add(currentCompletionTime);
			}
			tasksResources.set(i, temp);
		}

	}
}
