package xmu.lab.minmin.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FindTheMinimumTimeMap {
	public  static Map<Integer[], Double> findTheMinimumTimeMap(List<List<Double>> tasksResources) {
		//System.out.println("Size of columns: "+tasksResources.get(0).get(0));
		//store tasks and resources indexes and given name of the resources
		List<Integer[]>indexList=new ArrayList<Integer[]>();
		int colNum=tasksResources.get(0).size();//column number
		// System.out.println("colum number: "+colNum);
		Integer initialTasksId=(tasksResources.get(0).get(colNum-1).intValue()-1);
		//System.out.println("Task id===: "+initialTasksId);
		Integer []indexOfMin={0,0,initialTasksId};
		Double min=tasksResources.get(0).get(0);
		//System.out.println("Min: "+min);
		indexList.add(indexOfMin);

		//iterate the matrix to find the minimum time value;
		//all the intermediate pairs are also stores in the list

		int rowNum=tasksResources.size();
		//System.out.println("Row number: "+rowNum);
		for(int row=0;row<rowNum;row ++){
			//System.out.println("row: "+(tasksResources.get(row)));
			int colNumWithoutLastColum=tasksResources.get(row).size()-1;
			//int columnn=tasksResources.get(row).size();
			//System.out.println("col number is: "+columnn);
			for(int col=0;col<colNumWithoutLastColum;col++){
				Double current=tasksResources.get(row).get(col);
				//System.out.println("current : "+current);
				if (current<min){
					min=current;
					Integer targetTaskId=(tasksResources.get(row).get(colNumWithoutLastColum)).intValue();
					//System.out.println("Task resource List size "+tasksResources.size());
					//System.out.println(tasksResources.get(row).get(colNumWithoutLastColum));
					//System.out.println("========"+targetTaskId+"==============");
					Integer[] indexofCurrent={row,col,targetTaskId};
					indexList.add(indexofCurrent);
				}
			}
		}
		Map<Integer[], Double>map =new HashMap<Integer[], Double>();
		Integer[] rowAndColTaskid=new Integer[3];
		rowAndColTaskid[0]=indexList.get(indexList.size()-1)[0];
		rowAndColTaskid[1]=indexList.get(indexList.size()-1)[1];
		rowAndColTaskid[2]=indexList.get(indexList.size()-1)[2];

		map.put(rowAndColTaskid, min);


		return map;
	}
}
