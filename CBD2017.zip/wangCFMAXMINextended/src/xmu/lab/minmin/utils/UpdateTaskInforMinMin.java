package xmu.lab.minmin.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import a.xmu.lab.cfmaxmin.objects.Processors;
import a.xmu.lab.cfmaxmin.objects.Tasks;
import a.xmu.lab.cfmaxmin.objects.TimeGaps;
import aaaa.xmu.lab.cfmaxmin.utils.CalcMakeSpan;
import aaaa.xmu.lab.cfmaxmin.utils.UpdateTaskInforAfterChangeScheduling;

public class UpdateTaskInforMinMin {
	public static double updateTaskInforminmin(double maxTime, int ithToBeChangedTask, double sumCost, 
			List<Map.Entry<Integer, Double>> taskDisCostList,Map<Integer[], Double> map,
			ArrayList<Tasks> taskList, 
			HashMap<String, Integer> taskEdgeHashMap, Processors[] processorsArray){
		
		Tasks[] oldTaskInfor = new Tasks[taskList.size()];
		for(int i = 0; i < taskList.size(); ++ i){
			oldTaskInfor[i] = new Tasks();
			oldTaskInfor[i].selectedProcessorId = taskList.get(i).selectedProcessorId;
			oldTaskInfor[i].timeGap = new TimeGaps();
			oldTaskInfor[i].timeGap.startTime = taskList.get(i).timeGap.startTime;
			oldTaskInfor[i].timeGap.endTime = taskList.get(i).timeGap.endTime;
			oldTaskInfor[i].timeGap.gap = taskList.get(i).timeGap.gap;
		}
		Integer[]tasksReourcesIndexTaskid=GetRowandColsIndexAndTaskId.getRowandColsIndexAndTaskId(map);
	
		int taskindex=tasksReourcesIndexTaskid[0];
		int resourceIndex=tasksReourcesIndexTaskid[1];
		int taskid=tasksReourcesIndexTaskid[2];
//		Processor[] oldProcessorInfor = new Processor[processorsArray.length];
//		for(int i = 0; i < processorsArray.length; ++ i){
//			oldProcessorInfor[i] = new Processor();
//			oldProcessorInfor[i].availableTime = processorsArray[i].availableTime;
//		}
		
		int taskId = taskDisCostList.get(ithToBeChangedTask).getKey();
		Tasks task = taskList.get(taskId - 1);
//		double taskStartTime = task.timeGap.startTime;
		
		/**���Ĳ���**/
//		for(Task task1 :taskList){
//			task1.timeGap = new TimeGap();
//		}
		
		double disCost = taskDisCostList.get(ithToBeChangedTask).getValue(); 
	
		sumCost -= disCost;
		int updateIndex = taskindex;
		
		for(Processors processor: processorsArray){
			processor.availableTime = Double.MIN_VALUE;
		}
	
		for(; updateIndex < taskList.size(); ++ updateIndex){
			if(taskList.get(taskindex).taskId == taskId){
				break;
			}
			Tasks tempTask = taskList.get(taskList.get(taskindex).taskId - 1);
			int processorId = tempTask.selectedProcessorId;
			double tempAvailableTime = tempTask.timeGap.endTime;
			processorsArray[processorId].availableTime = Math.max(tempAvailableTime, processorsArray[processorId].availableTime);
		}
		

		ArrayList<Integer> predTaskArrayList = taskList.get(taskId - 1).predecessorTaskList;
		double timeThreshold = -1;
		for(Integer predTaskId: predTaskArrayList){
			double temp = 0;
			Tasks predTask = taskList.get(predTaskId - 1);
			if(predTask.selectedProcessorId == task.minCostProcessorId){
				temp = predTask.timeGap.endTime;
			}else{
				temp = predTask.timeGap.endTime + taskEdgeHashMap.get(predTaskId + "_" + taskId);
			}
			if(timeThreshold < temp){
				timeThreshold = temp;
			}
		}
		
		task.timeGap.startTime = Math.max(timeThreshold, processorsArray[task.minCostProcessorId].availableTime);
		task.selectedProcessorId = task.minCostProcessorId;
		task.timeGap.endTime = task.timeGap.startTime + task.minCostExcuteTime;
		task.timeGap.gap = task.minCostExcuteTime;
		processorsArray[task.minCostProcessorId].availableTime = task.timeGap.endTime;
		
		++ updateIndex;

		for(; updateIndex < taskList.size(); ++ updateIndex){
			UpdateTaskInforAfterChangeScheduling.updateTaskInfor(taskList.get(taskindex).taskId, taskList, taskEdgeHashMap, processorsArray);
		}
		
		if(maxTime < CalcMakeSpan.calcMakeSpan(taskList)){
			for(int i = 0; i < taskList.size(); ++ i){
				taskList.get(i).selectedProcessorId = oldTaskInfor[i].selectedProcessorId;
				taskList.get(i).timeGap.startTime = oldTaskInfor[i].timeGap.startTime;
				taskList.get(i).timeGap.endTime = oldTaskInfor[i].timeGap.endTime;
				taskList.get(i).timeGap.gap = oldTaskInfor[i].timeGap.gap;
			}

			sumCost += disCost;
		}
				
		return sumCost;
	}
}
