package xmu.lab.minmin.utils;

import java.util.Map;
import java.util.Map.Entry;

public class GetMinimumTimeValue {
	public static Double getMinimumTimeValue(Map<Integer[], Double> map) {
		Double value=0.0;
		for(Entry<Integer[], Double>entry:map.entrySet()){
			value=entry.getValue();
		}
		return value;
	}
}
