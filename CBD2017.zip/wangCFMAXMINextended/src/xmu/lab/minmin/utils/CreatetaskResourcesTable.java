package xmu.lab.minmin.utils;

import java.util.ArrayList;
import java.util.List;

import a.xmu.lab.cfmaxmin.objects.Processors;
import a.xmu.lab.cfmaxmin.objects.Tasks;

public class CreatetaskResourcesTable {
public static List<List<Double>> createtaskResourcestable(ArrayList<Tasks> mytasks, Processors[] myresources) {

		List<List<Double>>table=new ArrayList<List<Double>>();

		for(int i=0;i<mytasks.size();i++){
			Double originalTaskId=(double)mytasks.get(i).taskId;
			//System.out.println("the id of this is: "+originalTaskId);
			List<Double>temp=new ArrayList<>();
			for(int j=0;j<myresources.length;j++){
				double SingleExecution=mytasks.get(i).computationCost.get(j);
				//System.out.println(i+":"+SingleExecution);
				temp.add(SingleExecution);
				//System.out.println("temp without id: "+temp);
			}
			temp.add(originalTaskId);
			//System.out.println("temp with id"+temp);
			table.add(temp);
			//System.out.println(table.get(i).get(0));
			//System.out.println(table);
		}
		return table;
	}
}
