package xmu.lab.minmin.utils;

import java.util.Map;
import java.util.Map.Entry;

public class PrintMapForMinMin {
	public  static void printMapForMinMin(Map<Integer[], Double> map) {
		for(Entry<Integer[], Double>entry: map.entrySet()){
			Integer[]key=entry.getKey();
			Double value=entry.getValue();
			System.out.println("The key are: "+"{"+key[0]+","+key[1]+","+key[2]+"}");
			System.out.println("The min is "+ value+" located at row "+key[0]+" column "+key[1]+" and the task id is "+key[2]);
		}
	}
}
