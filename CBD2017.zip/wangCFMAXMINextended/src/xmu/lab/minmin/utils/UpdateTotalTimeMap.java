package xmu.lab.minmin.utils;

import java.util.List;

public class UpdateTotalTimeMap {
	public  static void updateTotalTimeMap(int resourceIndex,Double oldReadyTime, Double[] readyTime,List<List<Double>> TasksResources) {
		Double newReadyTime=readyTime[resourceIndex];
		Double readyTimeDifference=newReadyTime-oldReadyTime;
		for(int row =0; row <TasksResources.size();row++){
			Double oldTotalTime=TasksResources.get(row).get(resourceIndex);
			Double newTotalTime=oldTotalTime+readyTimeDifference;
			TasksResources.get(row).set(resourceIndex, newTotalTime);		
		}

	}
}
