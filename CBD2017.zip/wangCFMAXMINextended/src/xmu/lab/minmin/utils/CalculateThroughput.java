package xmu.lab.minmin.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;



public class CalculateThroughput {
	public static double calculateThroughput(Double[] readyTime,int taskNumber){
//		double MaxFinishTime=0.0;
//		int tasknum=mylist.size();
//		for(int i=0;i<tasknum;i++){
//			double currentFinishTime=mylist.get(i).timeGap.endTime;
//			//mylist.get(i).timeGap.endTime;
//			if(currentFinishTime>MaxFinishTime)
//				MaxFinishTime=currentFinishTime;;
//			//System.out.println("Maxfinished time"+MaxFinishTime);
//		}
//		double througput=tasknum/MaxFinishTime;
//		System.out.printf("The throughput is %.6f \n",througput);
//
//		return througput;
		List<Double>temp=new ArrayList<Double>(Arrays.asList(readyTime));
		Double throughput=taskNumber/(Collections.max(temp)+0.1);
		System.out.printf("The throughput is %.6f \n",throughput);

		return throughput;

	}
}
