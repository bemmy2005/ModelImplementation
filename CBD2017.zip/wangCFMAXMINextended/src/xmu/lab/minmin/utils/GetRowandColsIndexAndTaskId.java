package xmu.lab.minmin.utils;

import java.util.Map;
import java.util.Map.Entry;

public class GetRowandColsIndexAndTaskId {
	public static Integer[] getRowandColsIndexAndTaskId(Map<Integer[], Double> map) {
		Integer []key =new Integer[3];
		for(Entry<Integer[],Double>entry:map.entrySet()){
			key=entry.getKey();
			//System.out.println(key[0]);
		}
		return key;	
	}
}
