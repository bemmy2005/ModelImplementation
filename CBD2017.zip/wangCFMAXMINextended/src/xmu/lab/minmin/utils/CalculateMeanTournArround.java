package xmu.lab.minmin.utils;

import java.util.List;

import a.xmu.lab.cfmaxmin.objects.Tasks;

public class CalculateMeanTournArround {
	public static double CalculateAverageTournArround(List<Tasks>myList){
		//turnaround time=finishtime-arrivaltime
		double totaltime=0.0;
		int taskNum=myList.size();
		for(int i=0;i<taskNum;i++){
			totaltime+=myList.get(i).timeGap.gap;
			//System.out.println("totaltime "+totaltime);
		}
		double AverageTurnAround=totaltime/taskNum;
		System.out.printf("The average turnaround time is %.4f\n", AverageTurnAround);

		return AverageTurnAround;

	}
}
