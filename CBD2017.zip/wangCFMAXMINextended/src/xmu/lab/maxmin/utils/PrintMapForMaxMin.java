package xmu.lab.maxmin.utils;

import java.util.Map;
import java.util.Map.Entry;

public class PrintMapForMaxMin {
	public static void printMapForMaxMin(Map<Integer[], Double> map) {

		for(Entry<Integer[], Double>entry:map.entrySet()){
			Integer[]key=entry.getKey();
			Double value=entry.getValue();
			System.out.printf("{%d, %d, %d}===>",key[0],key[1],key[2]);
			System.out.printf("%.4f(%s), located at row %d column %d, and the task id is %d \n",value,"max ",key[0],key[1],key[2]);
		}
	}
}
