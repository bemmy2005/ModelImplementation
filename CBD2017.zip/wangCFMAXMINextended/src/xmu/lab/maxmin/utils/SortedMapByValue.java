package xmu.lab.maxmin.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class SortedMapByValue {
@SuppressWarnings("unchecked")
public static HashMap<Integer[], Double> sortedMapByValue(Map<Integer[], Double> map) {
		Set<Entry<Integer[],Double>>set=map.entrySet();
		List<Entry<Integer[],Double>>list=new ArrayList<Entry<Integer[],Double>>(set);

		Collections.sort(list,new Comparator<Map.Entry<Integer[], Double>>() {
			public int compare(Map.Entry<Integer[],Double >o1,Map.Entry<Integer[], Double>o2){
				return (o2.getValue()).compareTo(o1.getValue());
			}
		});
		//Here i am copying the sorted list in HashMap
		//Using LinkedhashMap to preserve the insertion order
		@SuppressWarnings("rawtypes")
		HashMap sortedHashMap=new LinkedHashMap<>();
		for(@SuppressWarnings("rawtypes")
		Iterator it =list.iterator();it.hasNext();){
			@SuppressWarnings("rawtypes")
			Map.Entry entry=(Map.Entry)it.next();
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}
		return sortedHashMap;
	}


	
	
}
