package xmu.lab.maxmin.utils;

import java.util.Map;
import java.util.Map.Entry;

public class GetRowandColIndexesAsTaskId {
public static Integer[] getRowandColIndexesAsTaskId(Map<Integer[], Double> map) {
		Integer []key =new Integer[3];
		for(Entry<Integer[],Double>entry:map.entrySet()){
			key=entry.getKey();
			//System.out.println(key[0]);
		}
		return key;	
	}
}
