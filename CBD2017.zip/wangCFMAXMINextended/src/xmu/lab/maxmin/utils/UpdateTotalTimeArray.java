package xmu.lab.maxmin.utils;

import java.util.List;

public class UpdateTotalTimeArray {
	public static void updateTotalTimeArray(int colIndex, Double oldTime,Double[] readyTime, List<List<Double>> tasksResourcesList) {

		Double newReadyTime=readyTime[colIndex];
		Double readyTimeDifference=newReadyTime-oldTime;
		for(int row =0; row <tasksResourcesList.size();row++){
			Double oldTotalTime=tasksResourcesList.get(row).get(colIndex);
			Double newTotalTime=oldTotalTime+readyTimeDifference;
			tasksResourcesList.get(row).set(colIndex, newTotalTime);		
		}

	}
}
