package xmu.lab.maxmin.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FindMaxMinTimeMap {
	public static Map<Integer[], Double> findMaxMinTimeMap(List<List<Double>> tasksResourcesList) {
		// Step 1: scan each row and find the minimum

		int rowNum=tasksResourcesList.size();
		int colsNum=tasksResourcesList.get(0).size();
		//last colum is the taskId
		int columNumWithouthLastCol=colsNum-1;

		Map<Integer[], Double>map=new HashMap<Integer[],Double>();
		for(int row=0; row<rowNum;row++){
			//Assume the first element in each row as minimum initially
			Double min=tasksResourcesList.get(row).get(0);

			//get the task_id
			Integer targetTaskId=tasksResourcesList.get(row).get(columNumWithouthLastCol).intValue();

			//information includes row, column and taskid
			//note the colum number is innitially 0;
			Integer []rowInfo={row,0,targetTaskId};

			for(int col=0;col<columNumWithouthLastCol;col++){
				Double current=tasksResourcesList.get(row).get(col);
				if(current<min){
					min=current;
					rowInfo[1]=col;//get the colum number
				}
			}
			map.put(rowInfo, min);
		}
		//step 2: find the max among the min-candidate in the map
		//it's a sorting problem basically
		//System.out.println("before sorting ");
		//PrintMapForMaxMin.printMapForMaxMin(map);
		//System.out.println("after sorting");

		HashMap<Integer[], Double>sortedMap=SortedMapByValue.sortedMapByValue(map);
		//PrintMapForMaxMin.printMapForMaxMin(map);
		Map<Integer[], Double>firstPair=GetFirstPairFromMap.getFirstPairFromMap(sortedMap);//===========problem here
		
		//PrintMapForMaxMin.printMapForMaxMin(sortedMap);


		return firstPair;
	}

}
