package xmu.lab.maxmin.utils;

import java.util.List;

import a.xmu.lab.cfmaxmin.objects.Tasks;

public class CalculateAverageTournArround {
	public static double calculateAverageTournArround(List<Tasks>myList){
		//turnaround time=finishtime-arrivaltime
		double totaltime=0.0;
		int taskNum=myList.size();
		for(int i=0;i<taskNum;i++){
			totaltime+=myList.get(i).timeGap.gap;
		}
		double AverageTurnAround=totaltime/taskNum;
		System.out.printf("The average turnaround time is %.4f\n", AverageTurnAround);

		return AverageTurnAround;

	}
}
