package xmu.lab.maxmin.utils;

import java.util.List;

public class PrintTasksResourcesList {
public static void printTasksResourcesList(List<List<Double>> table) {
		System.out.printf("The current matrix is as below, with size of %d by %d \n",table.size(),table.get(0).size());
		for(int i=0; i<table.size();i++){

			for(int j=0;j<table.get(i).size();j++){
				//System.out.println("This is :"+table.get(i).size());
				System.out.printf("%-11.7f",table.get(i).get(j));
				//System.out.println(table.get(0).get(2));
			}
			System.out.printf("\n");
		}
	}
}
