package xmu.lab.maxmin.utils;

import java.util.HashMap;
import java.util.Map;

public class GetFirstPairFromMap {
	public static Map<Integer[], Double> getFirstPairFromMap(HashMap<Integer[], Double> map) {
		//get the first pair of map
		Map.Entry<Integer[], Double>entry=map.entrySet().iterator().next();//=================problem here
		Integer[]key=entry.getKey();
		Double value=entry.getValue();
		Map<Integer[],Double>firstPair=new HashMap<Integer[],Double>();
		
		firstPair.put(key, value);

		return firstPair;
	}
}
