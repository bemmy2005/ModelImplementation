package xmu.lab.maxmin.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CalculateThroughputNew {
	public static double calculateThroughputNew(Double[] readyTime,int taskNumber) {
		List<Double>temp=new ArrayList<Double>(Arrays.asList(readyTime));
		Double throughput=taskNumber/(Collections.max(temp)+0.1);
		System.out.printf("The throughput is %.6f \n",throughput);

		return throughput;
	}
}
