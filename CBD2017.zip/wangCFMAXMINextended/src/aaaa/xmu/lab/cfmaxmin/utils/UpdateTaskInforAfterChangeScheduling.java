package aaaa.xmu.lab.cfmaxmin.utils;

import java.util.ArrayList;
import java.util.HashMap;

import a.xmu.lab.cfmaxmin.objects.Processors;
import a.xmu.lab.cfmaxmin.objects.Tasks;



public class UpdateTaskInforAfterChangeScheduling {
	
	public static void updateTaskInfor(int taskId, ArrayList<Tasks> taskList, 
			HashMap<String, Integer> taskEdgeHashMap, Processors[] processorsArray){

		Tasks task = taskList.get(taskId - 1);
		int processorId = task.selectedProcessorId;
		double est = CalcEST.calcEST(processorId, taskId, processorsArray[processorId].availableTime, taskList, taskEdgeHashMap);
		double eft = est + task.computationCost.get(processorId);
		
		task.timeGap.endTime = eft;
		task.timeGap.startTime = eft - task.computationCost.get(processorId);
		task.timeGap.gap = task.timeGap.endTime - task.timeGap.startTime;
		
//		processorsArray[processorId].taskList.add(taskId);
		processorsArray[processorId].availableTime = eft;
	}

}
