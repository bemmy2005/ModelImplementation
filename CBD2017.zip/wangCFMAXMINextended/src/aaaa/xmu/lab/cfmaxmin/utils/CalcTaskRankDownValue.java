package aaaa.xmu.lab.cfmaxmin.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Map.Entry;

import a.xmu.lab.cfmaxmin.objects.Tasks;

public class CalcTaskRankDownValue {
	public static ArrayList<Integer> calcTaskdownRankValue(ArrayList<Tasks> taskList, 
			HashMap<String, Integer> taskEdgeHashMap, int beginTask){
		
		HashMap<Integer, Double> taskIdRankdownValueMap = new HashMap<>();
		Queue<Integer> taskIdQueue = new LinkedList<>();
		taskIdQueue.offer(beginTask);
		
		while(taskIdQueue.size() > 0){
			
			int taskId = taskIdQueue.poll();
			ArrayList<Integer> predArrayList = taskList.get(taskId - 1).predecessorTaskList;
			
			boolean allPredCalced = true;
			for(int predTask: predArrayList){
				if(taskIdRankdownValueMap.get(predTask) == null){
					taskIdQueue.add(taskId);
					allPredCalced = false;
					break;
				}
			}
			
			if(allPredCalced){
				for(Integer succTask: taskList.get(taskId + 1).successorTaskList){
					if(!taskIdQueue.contains(succTask)){
						taskIdQueue.add(succTask);
					}		
				}
				
				double rankValue = 0.0;
				
				for(int succTask: predArrayList){
					Double predRankValue = taskIdRankdownValueMap.get(succTask);
					double newRankValue = predRankValue + taskEdgeHashMap.get(taskId + "_" + succTask + taskList.get(taskId + 1).averageCost);
					if(rankValue < newRankValue){
						rankValue = newRankValue;
					}
				}			
				taskIdRankdownValueMap.put(taskId, rankValue );
			}
			
		}
		
		//
		List<Map.Entry<Integer, Double>> taskIdRankdownValueList = new ArrayList<Map.Entry<Integer, Double>>(taskIdRankdownValueMap.entrySet());  
        Collections.sort(taskIdRankdownValueList, new Comparator<Map.Entry<Integer, Double>>() {

			@Override
			public int compare(Entry<Integer, Double> o1,
					Entry<Integer, Double> o2) {
				return o2.getValue().compareTo(o1.getValue());
			}  
              
  
        });  
        
        ArrayList<Integer> taskOrderDownList = new ArrayList<>();
        for (Map.Entry<Integer, Double> map : taskIdRankdownValueList) {  
            taskOrderDownList.add(map.getKey()); 
        } 
        
		return taskOrderDownList;
	}

	
	public static ArrayList<Integer> calcTaskRankValue1(ArrayList<Tasks> taskList, 
			HashMap<String, Integer> taskEdgeHashMap, int beginTask){
		
		HashMap<Integer, Double> taskIdRankValueMap = new HashMap<>();
		
		for(int i = beginTask; i >= 1; i--){
			taskIdRankValueMap.put(i, taskList.get(i - 1).averageCost);
			
			ArrayList<Integer> succArrayList = taskList.get(i - 1).successorTaskList;
			
			double rankValue = 0.0;
			
			for(int succTask: succArrayList){
				Double succRankValue = taskIdRankValueMap.get(succTask);
				double newRankValue = succRankValue + taskEdgeHashMap.get(i + "_" + succTask);
				if(rankValue < newRankValue){
					rankValue = newRankValue;
				}
			}			
			taskIdRankValueMap.put(i, rankValue + taskList.get(i- 1).averageCost);
			
		}
		
		//��rankֵ�Ӵ�С����
				List<Map.Entry<Integer, Double>> taskIdRankValueList = new ArrayList<Map.Entry<Integer, Double>>(taskIdRankValueMap.entrySet());  
		        Collections.sort(taskIdRankValueList, new Comparator<Map.Entry<Integer, Double>>() {

					@Override
					public int compare(Entry<Integer, Double> o1,
							Entry<Integer, Double> o2) {
						// TODO Auto-generated method stub
						return o2.getValue().compareTo(o1.getValue());//��������
					}  
		              
		  
		        });  
		        
		        ArrayList<Integer> taskOrderList = new ArrayList<>();
		        for (Map.Entry<Integer, Double> map : taskIdRankValueList) {  
		            taskOrderList.add(map.getKey()); 
		        } 
		        
				return taskOrderList;
	}
	
	
	
}
