package aaaa.xmu.lab.cfmaxmin.utils;

import java.util.ArrayList;

import a.xmu.lab.cfmaxmin.objects.Processors;
import a.xmu.lab.cfmaxmin.objects.Tasks;



public class CalcTaskMaxCost {
	
	public static void calcTaskMaxCost(double beta, ArrayList<Tasks> taskList, Processors[] processorArray){
		
		for(Tasks task: taskList){
			task.maxCost = CalcRunTime.calcRunTime(beta, processorArray[task.selectedProcessorId].fMax, processorArray[task.selectedProcessorId], task.computationCost.get(task.selectedProcessorId)) * processorArray[task.selectedProcessorId].costMaxUnit;
		}
		
	}

}
