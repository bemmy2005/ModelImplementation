package aaaa.xmu.lab.cfmaxmin.utils;

import java.util.ArrayList;
import java.util.HashMap;

import a.xmu.lab.cfmaxmin.objects.Tasks;



public class CalcEST {
	
	//���翪ʼʱ��
		public static double calcEST(int processorId, int taskId, double availableTime, ArrayList<Tasks> taskList, 
				HashMap<String, Integer> taskEdgeHashMap){
			
			ArrayList<Integer> predTaskArrayList = taskList.get(taskId - 1).predecessorTaskList;
			double maxFinishTime = -1.0;
			
			for(Integer predTaskId: predTaskArrayList){
				Tasks predTask = taskList.get(predTaskId - 1);
				double tempTime = 0.0;
				if(predTask.selectedProcessorId == processorId){
					tempTime = predTask.timeGap.endTime;
				}else{
					tempTime = predTask.timeGap.endTime + taskEdgeHashMap.get(predTaskId + "_" + taskId);
				}
				if(maxFinishTime < tempTime){
					maxFinishTime = tempTime;
				}
			}
			
			return Math.max(availableTime, maxFinishTime);
		}

}
