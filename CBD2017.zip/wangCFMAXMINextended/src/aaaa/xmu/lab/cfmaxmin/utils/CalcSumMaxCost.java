package aaaa.xmu.lab.cfmaxmin.utils;

import java.util.ArrayList;

import a.xmu.lab.cfmaxmin.objects.Tasks;



public class CalcSumMaxCost {
	
	public static int calcSumMaxCost(ArrayList<Tasks> taskList){
		
		int sumMaxCost = 0;
		
		for(Tasks task: taskList){
			sumMaxCost += task.maxCost;
		}
		
		return sumMaxCost;
	}

}
