package aaaa.xmu.lab.cfmaxmin.utils;

import java.util.ArrayList;

import a.xmu.lab.cfmaxmin.objects.Tasks;



public class CalcMakeSpan {

	public static double calcMakeSpan(ArrayList<Tasks> taskList){
		
		double makeSpan = Double.MIN_VALUE;
		
		for(Tasks task: taskList){
			if(makeSpan < task.timeGap.endTime){
				makeSpan = task.timeGap.endTime;
			}
		}
		
		return makeSpan;
	}
}
