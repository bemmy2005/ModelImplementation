package aaaa.xmu.lab.cfmaxmin.utils;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import a.xmu.lab.cfmaxmin.objects.Processors;
import a.xmu.lab.cfmaxmin.objects.Tasks;


public class ChangeFromMaxDisCost {
	
	public static void changeFromMaxDisCost(double maxTimeParameter, 
			List<Map.Entry<Integer, Double>> taskDisCostList,
			ArrayList<Tasks> taskList, ArrayList<Integer> taskOrderList,
			HashMap<String, Integer> taskEdgeHashMap, Processors[] processorsArray) throws IOException{
		
		//compute sum cost and makespan,deadline(maxTime)
		double sumCost = CalcSumMaxCost.calcSumMaxCost(taskList);
		double makespan = CalcMakeSpan.calcMakeSpan(taskList);
		double maxTime = makespan * maxTimeParameter;
		//System.out.println("Using HEFT \tmakespan: " + makespan + "\tsumCost: " + sumCost);
		//change from max cost
		System.out.println("Deadline: "+maxTime);
		
		double totalCount=0;//Number of times we changed CPU frequencies
		int FailedCounter=0;//Number of times the changed CPU frequency didn't lead to less makespan than Deadline
		int SuccessCounter=0;//number of times the changed frequency leads to makespan less than deadline;
		double RobustnessProbability=0.0;//the Probability of having the clear answer()
		double Tolerance=0.0;//how far is the makespan compared to deadline
		
		
		for(int i = 0; makespan <= maxTime && i < taskList.size(); makespan = CalcMakeSpan.calcMakeSpan(taskList), ++ i){
			double tempCost = sumCost;
			sumCost = UpdateTaskInfor.updateTaskInfor(maxTime, i, sumCost, taskDisCostList, taskList, taskOrderList, taskEdgeHashMap, processorsArray);
			if(Math.abs(tempCost - sumCost) < 1e-10){
				//break;//this stops the search so we can't continue to search for next solution
				SuccessCounter++;
			}
			else {
				FailedCounter++;
			}
		}
		totalCount=SuccessCounter+FailedCounter;
		RobustnessProbability=(totalCount-FailedCounter)/totalCount;
		Tolerance=maxTime-makespan;
		System.out.println("Using CFMAX \tmakespan: "+ makespan + "\tTotal Cost: " + sumCost+"\tRobustnessProb: "+RobustnessProbability+"\tTolerance: "+Tolerance);
		
		//System.out.println( makespan + "\t" + sumCost+"\t"+RobustnessProbability+"\t"+Tolerance);
	}

}
