package aaaa.xmu.lab.cfmaxmin.utils;

import a.xmu.lab.cfmaxmin.objects.Processors;



public class CalcCost {
	
	public static double getCost(int frequency, Processors processor){
		
		double cost = 0;
		
		switch (processor.costModel) {
		case 1:
			cost = calcCostModel1Linear(frequency, processor);
			break;
		case 2:
			cost = calcCostModel2Superlinear(frequency, processor);
			break;
		case 3:
			cost = calcCostModel3Sublinear(frequency, processor);
			break;
		}
		
		return cost;
	}
	
	private static double calcCostModel1Linear(int frequency, Processors processor){
		
		double costDif = 3.33;
		double cost = 0;
		double costMin = processor.costMinUnit;
		int fMin = processor.fMin;
		
		cost = costMin + costDif * ((frequency * 1.0 - fMin) / fMin);
		
		return cost;
	}
	
	private static double calcCostModel2Superlinear(int frequency, Processors processor){
		
		double costDif = 4.44;
		double cost = 0;
		double costMin = processor.costMinUnit;
		int fMin = processor.fMin;
		
		cost = costMin + costDif * ((1 + (frequency * 1.0 - fMin) / fMin) * Math.log(1 + (frequency - fMin) / fMin));
		//System.out.println("ahahahahahah"+frequency*1.0);
		return cost;
	}
	
	private static double calcCostModel3Sublinear(int frequency, Processors processor){
		
		double costDif = 12;
		double cost = 0;
		double costMin = processor.costMinUnit;
		int fMin = processor.fMin;
		
		cost = costMin + costDif * Math.log(1 + (frequency * 1.0 - fMin) / fMin);
		//System.out.println("ahahahahahah"+frequency*1.0);
		return cost;
	}

}
