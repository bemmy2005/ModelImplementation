package aaaa.xmu.lab.cfmaxmin.utils;

import a.xmu.lab.cfmaxmin.objects.Processors;



public class CalcRunTime {

	public static double calcRunTime(double beta, int frequency, Processors processor, double runTimeMax) {
		
		double runTime = 0;
		
		runTime = (beta * (processor.fMax * 1.0 / frequency - 1) + 1) * runTimeMax;
		
		return runTime;
	}
}
