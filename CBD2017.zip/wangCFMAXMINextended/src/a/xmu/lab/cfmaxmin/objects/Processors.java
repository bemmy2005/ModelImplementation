package a.xmu.lab.cfmaxmin.objects;

import java.util.ArrayList;

public class Processors {
	
	public int processorId;       //id
	public int fLevel;            //������Ƶ�ʲ���      
	public int fMax;              //max frequency
	public int fMin;              //min frequency
	public double costMaxUnit;           //per unit of time cost at max frequency
	public double costMinUnit;           //per unit of time cost at min frequency
	public int costModel;         //cost model 
	public double availableTime = 0.0; //available time 
	
	public ArrayList<TimeGaps> timeGapList = new ArrayList<>();  //the idle time list
	
	
}
