package a.xmu.lab.cfmaxmin.objects;

import java.util.ArrayList;

public class Tasks{
	
	public double maxCost;// the cost when this task is scheduled on maximum frequency
	
	public int taskId;               //id
	public double averageCost;       //average computation cost
	public int selectedProcessorId;  // the id of processor  for executing time
	public int rankUp;
	public int rankDown;
	public double minCost;              //the min cost in all procesors
	public double minCostExcuteTime;    //the execution time when the cost is minimum
	public double minCostUnit;
	public int minCostProcessorId;   //the id of processot with min cost
	public int minCostProcessorLevel;//������С�����µĵڼ����������ô���������СƵ�ʼ��ϸ�ֵ*�ô������Ĳ�������ȡ����С���۵�Ƶ��       

	public TimeGaps timeGap = new TimeGaps(); //execution start time,finish time,execution time
	
	public ArrayList<Double> computationCost = new ArrayList<>();        //the execution time list at highest frequency of each frequency
	public ArrayList<Integer> predecessorTaskList = new ArrayList<>();    //predecessorTask
	public ArrayList<Integer> successorTaskList = new ArrayList<>();      //successorTask

}
