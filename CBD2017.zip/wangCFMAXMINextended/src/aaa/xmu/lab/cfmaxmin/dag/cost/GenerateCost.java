package aaa.xmu.lab.cfmaxmin.dag.cost;
import java.io.IOException;

import aa.xmu.lab.cfmaxmin.dag.cost.GetCost;


public class GenerateCost {

	public static void main(String[] args) throws IOException{
		GetCost.getCost("Montage3.txt", 102, 3);
		GetCost.getCost("Montage5.txt", 102, 5);
		GetCost.getCost("Montage8.txt", 102, 8);

		GetCost.getCost("Ligo3.txt", 77, 3);
		GetCost.getCost("Ligo5.txt", 77, 5);
		GetCost.getCost("Ligo8.txt", 77, 8);

		GetCost.getCost("Airsn3.txt", 53, 3);
		GetCost.getCost("Airsn5.txt", 53, 5);
		GetCost.getCost("Airsn8.txt", 53, 8);

		//		GetCost.getCost("D:\\workspace\\�����޸�\\FrequenceHEFT\\Sdss3.txt", 124, 3);
		//		GetCost.getCost("D:\\workspace\\�����޸�\\FrequenceHEFT\\Sdss5.txt", 124, 5);
		//		GetCost.getCost("D:\\workspace\\�����޸�\\FrequenceHEFT\\Sdss8.txt", 124, 8);

		GetCost.getCost("Sdss3.txt", 124, 3);
		GetCost.getCost("Sdss5.txt", 124, 5);
		GetCost.getCost("Sdss8.txt", 124, 8);


	}
}
