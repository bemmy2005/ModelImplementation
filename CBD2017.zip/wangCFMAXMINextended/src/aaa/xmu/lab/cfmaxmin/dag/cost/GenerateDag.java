package aaa.xmu.lab.cfmaxmin.dag.cost;
import java.io.IOException;

import aa.xmu.lab.cfmaxmin.dag.cost.GetDag;



public class GenerateDag {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		GetDag.getMontage("Montage.txt");
		GetDag.getLigo("Ligo.txt");
		GetDag.getAirsn("Airsn.txt");
		GetDag.getAirsn("Airsn.txt");
		GetDag.getSdss("Sdss.txt");
		//GetDag.getSdss("E:\\workspaces\\FrequenceHEFT\\sdss.txt");

	}

}
