package driver;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import xmu.lab.minmin.utils.CalculateMeanTournArround;
import xmu.lab.minmin.utils.CalculateThroughput;
import xmu.lab.minmin.utils.ChangeFromMaxDisCostMinMin;
import xmu.lab.minmin.utils.ChangeFromMinDisCostMinMin;
import xmu.lab.minmin.utils.CreatetaskResourcesTable;
import xmu.lab.minmin.utils.FindTheMinimumTimeMap;
import xmu.lab.minmin.utils.GetMinimumTimeValue;
import xmu.lab.minmin.utils.GetRowandColsIndexAndTaskId;
import xmu.lab.minmin.utils.UpdateTotalTimeMap;

import a.xmu.lab.cfmaxmin.objects.Processors;
import a.xmu.lab.cfmaxmin.objects.Tasks;
import aaaa.xmu.lab.cfmaxmin.utils.CalcTaskMaxCost;
import aaaa.xmu.lab.cfmaxmin.utils.ChangeFromMaxDisCost;
import aaaa.xmu.lab.cfmaxmin.utils.ChangeFromMinDisCost;
import aaaa.xmu.lab.cfmaxmin.utils.GetDisCostTaskOrder;
import aaaa.xmu.lab.cfmaxmin.utils.GetMinCostProcessorIdLevel;
import aaaaa.xmu.lab.cfmaxmin.InputManager.InputManage;

public class RunMinMin {
	public static void runMINMIN(double maxTimeParameter, int processorNums, int taskNums, double beta, boolean changeOrder,
			String computationCostPath, String inputGraphPath, String processorInfor) throws IOException{
		//the class used for initialing
		InputManage inputmanager = new InputManage();
		//initial task info
		ArrayList<Tasks> taskList = inputmanager.initTaskInfor(computationCostPath, inputGraphPath);
		//initial communication data
		HashMap<String, Integer> taskEdgeHashMap = inputmanager.initTaskEdge();

		//initial processor info
		Processors[] processorsArray = new Processors[processorNums];
		processorsArray = inputmanager.initProcessorInfor(processorInfor, processorNums);
		
		Double[]readyTime=new Double[processorNums];
		for(int i=0;i<taskNums;i++){
			readyTime[i]=processorsArray[i].availableTime;
		}
		List<List<Double>>TasksResources=CreatetaskResourcesTable.createtaskResourcestable(taskList,processorsArray);
		//InitializeTotalTime(TasksResources,readyTime);//============Caused problem

		int count=1;
		do{
			//System.out.println("========================");
			//System.out.println("Iteration number "+ count);
			//PrintTaskResources.printTaskResources(TasksResources);


			//Step 1. find the minimum number
			Map<Integer[], Double>map=FindTheMinimumTimeMap.findTheMinimumTimeMap(TasksResources);
			//PrintMapForMinMin.printMapForMinMin(map);

			//Step 2: retrieve all information from the map
			Integer[]tasksReourcesIndexTaskid=GetRowandColsIndexAndTaskId.getRowandColsIndexAndTaskId(map);
			Double minDouble=GetMinimumTimeValue.getMinimumTimeValue(map);
			int taskindex=tasksReourcesIndexTaskid[0];
			int resourceIndex=tasksReourcesIndexTaskid[1];
			int taskid=tasksReourcesIndexTaskid[2];//change in the map/table add the last column double of tasksid// not an issue
			//double taskid=(double)taskindex;

			//System.out.println("Minimum Value: "+minDouble);
			//System.out.println("Task Index: "+taskindex);
			//System.out.println("Resource Id:"+resourceIndex);
			//System.out.println("Task Id: "+taskid);

			//3. Assign the tasks to the resources based on min-min
			//			System.out.println("Taskindex: "+taskindex);
			//			System.out.println("resources id:"+resourceIndex);
			//			System.out.println("Task id is:"+taskid);

			//mytasks.get(taskid).resourceId=resourceIndex;
			//System.out.println("resource id is "+resourceIndex);
			//taskindex must not be printed here but taskid //===========Caused problem
			//double costs=minDouble*mytasks.get(taskindex).minCostProcessorId;
			//System.out.println("The Taskid:"+taskid +" has been assigned to resource: "+resourceIndex+" Execution time: "+minDouble);
			taskList.get(taskindex).selectedProcessorId=resourceIndex;//mytasks.get(taskid).setResourcesId(myresources.get(colIndex).getId);
			System.out.printf("The Task %d has been assigned to resource %d \n",taskid,resourceIndex);
		
			//step 4:update ready time array;
			Double oldReadyTime=readyTime[resourceIndex];//store the old value
			readyTime[resourceIndex]=minDouble;
			//System.out.println("The ready time array is: "+Arrays.toString(readyTime));//==================
			// step 5  update the task-vm with the current ready time
			UpdateTotalTimeMap.updateTotalTimeMap(resourceIndex,oldReadyTime,readyTime,TasksResources);
			//step 6: remove the row after the task has been assigned
			TasksResources.remove(taskindex);
			//System.out.println("This is the end of iteration "+count);
			//System.out.println("============================");


			++count;
		}while(TasksResources.size()>0);
		CalcTaskMaxCost.calcTaskMaxCost(beta, taskList, processorsArray);
		//3.b
		//compute min cost in all processors
		GetMinCostProcessorIdLevel.getMinCostProcessorIdLevel(beta, taskList, processorsArray);
		//3.c
		//rank task by cost difference
		List<Map.Entry<Integer, Double>> taskDisCostList = GetDisCostTaskOrder.getDisCostTaskOrder(taskList);
		//4
		if(changeOrder){
			//change from max cost
			ChangeFromMaxDisCostMinMin.changeFromMaxDisCostMinMin(maxTimeParameter, taskDisCostList, taskList, taskEdgeHashMap, processorsArray,TasksResources);
		//5
		}else{
			//change from min cost
			ChangeFromMinDisCostMinMin.changeFromMinDisCostminmin(maxTimeParameter, taskDisCostList, taskList, taskEdgeHashMap, processorsArray, TasksResources);
		}
		//==============================================
		System.out.println("\n");
		//TurnArround
		CalculateMeanTournArround.CalculateAverageTournArround(taskList);
		//Throughput
		//CalculateThroughput.calculateThroughput(taskList);
		
	}
}
