package driver;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import a.xmu.lab.cfmaxmin.objects.Processors;
import a.xmu.lab.cfmaxmin.objects.Tasks;
import aaaa.xmu.lab.cfmaxmin.utils.CalcArrayListSum;
import aaaa.xmu.lab.cfmaxmin.utils.CalcTaskMaxCost;
import aaaa.xmu.lab.cfmaxmin.utils.CalcTaskRankUpValue;
import aaaa.xmu.lab.cfmaxmin.utils.ChangeFromMaxDisCost;
import aaaa.xmu.lab.cfmaxmin.utils.ChangeFromMinDisCost;
import aaaa.xmu.lab.cfmaxmin.utils.GetDisCostTaskOrder;
import aaaa.xmu.lab.cfmaxmin.utils.GetMinCostProcessorIdLevel;
import aaaaa.xmu.lab.cfmaxmin.InputManager.InputManage;
import aaaaaa.xmu.lab.scheduler.HeftTaskScheduling;




public class RunHEFT {
	public static void runHEFT(double maxTimeParameter, int processorNums, int taskNums, double beta, boolean changeOrder,
			String computationCostPath, String inputGraphPath, String processorInfor) throws IOException{

				//the class used for initialing
				InputManage inputmanager = new InputManage();
				//initial task info
				ArrayList<Tasks> taskList = inputmanager.initTaskInfor(computationCostPath, inputGraphPath);
				//initial communication data
				HashMap<String, Integer> taskEdgeHashMap = inputmanager.initTaskEdge();

				//initial processor info
				Processors[] processorsArray = new Processors[processorNums];
				processorsArray = inputmanager.initProcessorInfor(processorInfor, processorNums);
				
				
				//1.
				//compute average computation time using for the rank
				for(int i = 0; i < taskNums; ++ i){
					Tasks tempTask = taskList.get(i);
					taskList.get(i).averageCost = CalcArrayListSum.calcArrayListSum(tempTask.computationCost) / processorNums;
				}
				//2
				//compute rank,then sort
				ArrayList<Integer> taskOrderList = CalcTaskRankUpValue.calcTaskRankValue1(taskList, taskEdgeHashMap, taskNums);
				//3
				//scheduling using HEFT
				for(Integer taskId: taskOrderList){
					HeftTaskScheduling.taskScheduling(taskId, taskList, taskEdgeHashMap, processorsArray);
				}
				//3.a
				CalcTaskMaxCost.calcTaskMaxCost(beta, taskList, processorsArray);
				//3.b
				//compute min cost in all processors
				GetMinCostProcessorIdLevel.getMinCostProcessorIdLevel(beta, taskList, processorsArray);
				//3.c
				//rank task by cost difference
				List<Map.Entry<Integer, Double>> taskDisCostList = GetDisCostTaskOrder.getDisCostTaskOrder(taskList);
				//4
				if(changeOrder){
					//change from max cost
					ChangeFromMaxDisCost.changeFromMaxDisCost(maxTimeParameter, taskDisCostList, taskList, taskOrderList, taskEdgeHashMap, processorsArray);
				//5
				}else{
					//change from min cost
					ChangeFromMinDisCost.changeFromMinDisCost(maxTimeParameter, taskDisCostList, taskList, taskOrderList, taskEdgeHashMap, processorsArray);
				}
							
	}

}
