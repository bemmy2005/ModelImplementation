package main.main.driver;

import java.io.IOException;
import java.util.ArrayList;

import driver.RunHEFT;

public class RunMontage {
//run on Montage
	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		
		int taskNums = 102;
		double beta = 0.4;
		String dirPath = "";
		String graphModelName = "Montage";
		String inputGraphPath = dirPath + "Montage.txt";
		
		ArrayList<Integer> processorNumsArray = new ArrayList<>();
		processorNumsArray.add(3);
		processorNumsArray.add(5);
		processorNumsArray.add(8);
		
		ArrayList<Double> maxTimeParatemerArray = new ArrayList<>();
		maxTimeParatemerArray.add(1.5);//what is this for!
		maxTimeParatemerArray.add(2.5);
		maxTimeParatemerArray.add(5.0);
		
		for(Integer processorNum: processorNumsArray){
			for(Double maxTimeParameter: maxTimeParatemerArray){
				String computationCostPath = dirPath + graphModelName + processorNum + ".txt";
				String processorInfor = dirPath + processorNum + ".txt";
				System.out.println("Number of Processor: "+processorNum+"\tDeadline ratio: "+maxTimeParameter);
				System.out.println("===========================================================================");
				//System.out.println(processorNum + "\t" + maxTimeParameter + "\t" + "Montage CFMAX");
				RunHEFT.runHEFT(maxTimeParameter, processorNum, taskNums, beta, true, computationCostPath, inputGraphPath, processorInfor);
				//System.out.println(processorNum + "\t" + maxTimeParameter + "\t" + "Montage CFMIN");
				RunHEFT.runHEFT(maxTimeParameter, processorNum, taskNums, beta, false, computationCostPath, inputGraphPath, processorInfor);
				System.out.println("======================================================================================================================================================");
			}
		}

	}

}
