package main.main.driver;

import java.io.IOException;
import java.util.ArrayList;

import driver.RunHEFT;

public class RunLigo {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		
		int taskNums = 77;
		double beta = 0.4;
		String dirPath = "";//D:\\workspaces\\FrequenceHEFT\\
		String graphModelName = "Ligo";
		String inputGraphPath = dirPath + "Ligo.txt";
		
		ArrayList<Integer> processorNumsArray = new ArrayList<>();
		processorNumsArray.add(3);
		processorNumsArray.add(5);
		processorNumsArray.add(8);
		
		ArrayList<Double> maxTimeParatemerArray = new ArrayList<>();
		maxTimeParatemerArray.add(1.5);
		maxTimeParatemerArray.add(2.5);
		maxTimeParatemerArray.add(5.0);
		
		for(Integer processorNum: processorNumsArray){
			for(Double maxTimeParameter: maxTimeParatemerArray){
				String computationCostPath = dirPath + graphModelName + processorNum + ".txt";
				String processorInfor = dirPath + processorNum + ".txt";
				System.out.println(processorNum + "\t" + maxTimeParameter + "\t" + "Ligo CFMAX");
				RunHEFT.runHEFT(maxTimeParameter, processorNum, taskNums, beta, true, computationCostPath, inputGraphPath, processorInfor);
				System.out.println(processorNum + "\t" + maxTimeParameter + "\t" + "Ligo CFXMIN");
				RunHEFT.runHEFT(maxTimeParameter, processorNum, taskNums, beta, false, computationCostPath, inputGraphPath, processorInfor);
			}
		}

	}

}
