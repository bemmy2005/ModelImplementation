package aaaaaa.xmu.lab.scheduler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import a.xmu.lab.cfmaxmin.objects.Processors;
import a.xmu.lab.cfmaxmin.objects.Tasks;
import a.xmu.lab.cfmaxmin.objects.TimeGaps;
import aaaa.xmu.lab.cfmaxmin.utils.CalcEST;

public class MinMinTaskScheduling {
	public static void taskScheduling(int taskId, ArrayList<Tasks> taskList, 
			HashMap<String, Integer> taskEdgeHashMap, Processors[] processorsArray){

		Tasks task = taskList.get(taskId - 1);
		int selectedProcessorId = -1;
		double minEFT = Double.MAX_VALUE;
	
		for(int i = 0; i < processorsArray.length; ++ i){

			double availableTime = processorsArray[i].availableTime;

//		
//			double gapInsertStartTime = getTimeGap(i, taskId, taskList, taskEdgeHashMap, processorsArray);
//			if(gapInsertStartTime > 0){
//				//				processorsArray[i].taskList.add(taskId);
//				task.selectedProcessorId = i;
//				task.timeGap.startTime = gapInsertStartTime;
//				task.timeGap.endTime = gapInsertStartTime + task.computationCost.get(i);
//				task.timeGap.gap = task.timeGap.endTime - task.timeGap.startTime;
//				return;
//			}

			
			double est = CalcEST.calcEST(i, taskId, availableTime, taskList, taskEdgeHashMap);
			double tempEFT = est + task.computationCost.get(i);
			if(minEFT > tempEFT){
				minEFT = tempEFT;
				selectedProcessorId = i;
			}
		}

		double oldAvailableTime = processorsArray[selectedProcessorId].availableTime;

		task.selectedProcessorId = selectedProcessorId;
		task.timeGap.endTime = minEFT;
		task.timeGap.startTime = minEFT - task.computationCost.get(selectedProcessorId);
		task.timeGap.gap = task.timeGap.endTime - task.timeGap.startTime;
		processorsArray[selectedProcessorId].availableTime = minEFT;
		if(oldAvailableTime < task.timeGap.startTime){
			TimeGaps timeGap = new TimeGaps(oldAvailableTime, task.timeGap.startTime);
			processorsArray[selectedProcessorId].timeGapList.add(timeGap);
		}
	}

	//Ѱ�ҿ��е�ʱ��Ƭ�Σ�������Բ��뷵�ز������ʼʱ�䣬���򷵻�-1
	@SuppressWarnings("unused")
	private static double getTimeGap(int processorId, int taskId, ArrayList<Tasks> taskList, 
			HashMap<String, Integer> taskEdgeHashMap, Processors[] processorsArray){
		//����ֵ
		double startTime = -1;

		//Ѱ�Ҹ��ڵ��������������ʱ��
		ArrayList<Integer> predTaskArrayList = taskList.get(taskId - 1).predecessorTaskList;
		//���ڵ����������ʱ��
		double timeThreshold = -1;
		for(Integer predTaskId: predTaskArrayList){
			double temp = 0;
			Tasks predTask = taskList.get(predTaskId - 1);
			if(predTask.selectedProcessorId == processorId){
				temp = predTask.timeGap.endTime;
			}else{
				temp = predTask.timeGap.endTime + taskEdgeHashMap.get(predTaskId + "_" + taskId);
			}
			if(timeThreshold < temp){
				timeThreshold = temp;
			}
		}

		//�����������Ŀ���Ƭ�Σ�������������Բ���
		ArrayList<TimeGaps> timeGapList = processorsArray[processorId].timeGapList;
		Collections.sort(timeGapList);
		double taskExcuteTime = taskList.get(taskId - 1).computationCost.get(processorId);
		for(TimeGaps timeGap: timeGapList){
			//��һ�ֲ������������֮����¿���ʱ��Ƭ��
			if(timeGap.startTime >= timeThreshold && timeGap.gap >= taskExcuteTime){
				startTime = timeGap.startTime;
				TimeGaps newTimeGap = new TimeGaps(startTime + taskExcuteTime, timeGap.endTime);
				timeGapList.remove(timeGap);
				timeGapList.add(newTimeGap);
				break;
			}
			//�ڶ��ֲ������������֮����¿���ʱ��Ƭ��
			if(timeGap.endTime - taskExcuteTime >= timeThreshold && timeGap.endTime - timeThreshold <= timeGap.gap){
				startTime = timeThreshold;
				TimeGaps newTimeGap1 = new TimeGaps(timeGap.startTime, timeThreshold);
				timeGapList.add(newTimeGap1);
				TimeGaps newTimeGap2 = new TimeGaps(timeThreshold + taskExcuteTime, timeGap.endTime);
				timeGapList.add(newTimeGap2);
				timeGapList.remove(timeGap);
				break;
			}					
		}

		return startTime;
	}

}
