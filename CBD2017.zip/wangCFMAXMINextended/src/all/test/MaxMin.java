package all.test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import xmu.lab.maxmin.utils.CalculateAverageTournArround;
import xmu.lab.maxmin.utils.CalculateThroughputNew;
import xmu.lab.maxmin.utils.CreateTasksResourcesTable;
import xmu.lab.maxmin.utils.FindMaxMinTimeMap;
import xmu.lab.maxmin.utils.GetMinimumTImeValue;
import xmu.lab.maxmin.utils.GetRowandColIndexesAsTaskId;
import xmu.lab.maxmin.utils.PrintMapForMaxMin;
import xmu.lab.maxmin.utils.PrintTasksResourcesList;
import xmu.lab.maxmin.utils.UpdateTotalTimeArray;

import a.xmu.lab.cfmaxmin.objects.Processors;
import a.xmu.lab.cfmaxmin.objects.Tasks;
import aaaa.xmu.lab.cfmaxmin.utils.CalcCost;
import aaaa.xmu.lab.cfmaxmin.utils.CalcTaskMaxCost;
import aaaaa.xmu.lab.cfmaxmin.InputManager.InputManage;


public class MaxMin {
	
	
	public static void main(String[] args) throws IOException {
		
		//========Initial input informations
		int maxTime = 5;         //Maximum Time
		int recourcesNum = 3;    //Number of resources
		int taskNums = 10;        //Number of Tasks
		double beta = 0.2;        //Betta in the equation
		
		//==== String Input files
		String computationCostPath = "computationCost.txt";
		String inputGraphPath = "inputGraph.txt";
		String processorInfor = "processorInfor.txt";
		//===creates objects for this calss
		//Initial schedule/initialize the schedule
		InputManage inputmanager = new InputManage();
		//List of tasks
		ArrayList<Tasks> mytasks = inputmanager.initTaskInfor(computationCostPath, inputGraphPath);
		//Map of Tasks and Edges
		HashMap<String, Integer> taskEdgeHashMap = inputmanager.initTaskEdge();
		//Processor array
		Processors[] myresources = new Processors[recourcesNum];
		myresources = inputmanager.initProcessorInfor(processorInfor, recourcesNum);
		//=========================================================
		///Max min Starts from here
//		int taskNumber=mytasks.size();
//		int resourrcesNum=myresources.length;

		//Ready time for each machine; initially to be zero
		Double[]readyTime=new Double[recourcesNum];
		for(int i=0;i<readyTime.length;i++){
			readyTime[i]=myresources[i].availableTime;
		}
		//========================================
		//Initialize the tasks-resources 2 dimension Array and their execution time
		List<List<Double>>TasksResourcesList=CreateTasksResourcesTable.createTasksResourcesTable(mytasks,myresources);

		int counter=0;

		do{
			//System.out.println("========================");
			//System.out.println("This is start of iteration "+counter);
			//PrintTasksResourcesList.printTasksResourcesList(TasksResourcesList);

			//1. find the smallest in each row; and find the largest of all
			Map<Integer[], Double>map=FindMaxMinTimeMap.findMaxMinTimeMap(TasksResourcesList);//===========problem here
			//PrintMapForMaxMin.printMapForMaxMin(map);

			//step2: retrieve all the information from the map
			Integer[]taskresourcesIndexAndTaskId=GetRowandColIndexesAsTaskId.getRowandColIndexesAsTaskId(map);
			Double Maxmin=GetMinimumTImeValue.getMinimumTImeValue(map);
			int rowIndex=taskresourcesIndexAndTaskId[0];
			int colIndex=taskresourcesIndexAndTaskId[1];
			int taskid=taskresourcesIndexAndTaskId[2];
			//mask of cost
			//double price=myresources[colIndex].fMax;
			//Double executiont=mytasks.get(rowIndex).computationCost.get(colIndex);
			//double cost=price+executiont;
             //mask cost
			//step 3  assignthe tasks to the resources
			mytasks.get(rowIndex).selectedProcessorId=colIndex;//mytasks.get(taskid).setResourcesId(myresources.get(colIndex).getId);
			//double cost =CalcCost.getCost(frequency, processor)
			//System.out.println("Taskid\tresourceid\tcomp t\tcost");
			//System.out.printf("%d\t%d\t%.1f%.3f",taskid,colIndex,Maxmin,cost);
			System.out.printf("The Taskid: %d resourceid: %d completiontime: %.4f \n",taskid,colIndex,Maxmin);

			//4 update ready time arrayy;
			Double oldTime=readyTime[colIndex];
			readyTime[colIndex]=Maxmin;
			//System.out.printf("The ready time array is %s \n", Arrays.toString(readyTime));

			//Step 5: update the task-resources matrix with current ready time
			UpdateTotalTimeArray.updateTotalTimeArray(colIndex,oldTime,readyTime,TasksResourcesList);

			//step 6: remove the row after task has been assigned
			TasksResourcesList.remove(rowIndex);


			//System.out.println("This is the end of iteration "+counter);
			//System.out.println("=============================");

			++counter;

		}while (TasksResourcesList.size()>0);
		
		CalculateThroughputNew.calculateThroughputNew(readyTime,taskNums);
		CalculateAverageTournArround.calculateAverageTournArround(mytasks);



	}

}
