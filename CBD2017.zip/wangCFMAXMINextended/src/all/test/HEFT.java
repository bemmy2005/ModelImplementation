package all.test;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import a.xmu.lab.cfmaxmin.objects.Processors;
import a.xmu.lab.cfmaxmin.objects.Tasks;
import aaaa.xmu.lab.cfmaxmin.utils.CalcArrayListSum;
import aaaa.xmu.lab.cfmaxmin.utils.CalcTaskMaxCost;
import aaaa.xmu.lab.cfmaxmin.utils.CalcTaskRankUpValue;
import aaaa.xmu.lab.cfmaxmin.utils.ChangeFromMaxDisCost;
import aaaa.xmu.lab.cfmaxmin.utils.ChangeFromMinDisCost;
import aaaa.xmu.lab.cfmaxmin.utils.GetDisCostTaskOrder;
import aaaa.xmu.lab.cfmaxmin.utils.GetMinCostProcessorIdLevel;
import aaaaa.xmu.lab.cfmaxmin.InputManager.InputManage;
import aaaaaa.xmu.lab.scheduler.HeftTaskScheduling;





public class HEFT {

	public static void main(String[] args) throws IOException{
		//=====================================================
		//=====================================================
		int maxTime = 5;         //Maximum Time
		int processorNums = 3;    //Number of resources
		int taskNums = 10;        //Number of Tasks
		double beta = 0.2;        //Betta in the equation
		//computationCost.txt: taskId	p1runtime	p2runtime	p3runtime
		String computationCostPath = "computationCost.txt";//"D:\\workspace\\FrequenceHEFT\\computationCost.txt"
		//inputGraph.txt: taskId1		taskId2		transportTime
		String inputGraphPath = "inputGraph.txt";//"D:\\workspace\\FrequenceHEFT\\inputGraph.txt";
		//processorInfor.txt: processorId	fmax	fmin	flevel/Differance	cmin	costMode/Pricing Model
		String processorInfor = "processorInfor.txt";//"D:\\workspace\\FrequenceHEFT\\processorInfor.txt"
		//Initial schedule/initialize the schedule
		InputManage inputmanager = new InputManage();
		//List of tasks
		ArrayList<Tasks> taskList = inputmanager.initTaskInfor(computationCostPath, inputGraphPath);
		//Map of Tasks and Edges
		HashMap<String, Integer> taskEdgeHashMap = inputmanager.initTaskEdge();
		//Processor array
		Processors[] processorsArray = new Processors[processorNums];
		processorsArray = inputmanager.initProcessorInfor(processorInfor, processorNums);
		//=====================================================================
		//=====================================================================

		//Step 1: Average computation cost HEFT
		//=======================
		//Average computation time
		for(int i = 0; i < taskNums; ++ i){
			Tasks tempTask = taskList.get(i);
			taskList.get(i).averageCost = CalcArrayListSum.calcArrayListSum(tempTask.computationCost) / processorNums;;
		}
		//Step 2: Rank Upwards   HEFT
		//=======================
		//Rank upwards
		ArrayList<Integer> taskOrderList = CalcTaskRankUpValue.calcTaskRankValue(taskList, taskEdgeHashMap, taskNums);

		//put tasks on list.
		for(Integer taskId: taskOrderList){
			HeftTaskScheduling.taskScheduling(taskId, taskList, taskEdgeHashMap, processorsArray);
		}
		//Step 2 a: cost          HEFT
		//=======================
		CalcTaskMaxCost.calcTaskMaxCost(beta, taskList, processorsArray);

		//
		System.out.println("HEFT schedule");
		//		for(Task task: taskList){
		//			System.out.println(task.taskId + "\t" + (task.selectedProcessorId + 1) + "\t" + task.timeGap.startTime + "\t" + task.timeGap.endTime);
		//		}
		for(Integer taskId: taskOrderList){
			System.out.println(taskList.get(taskId - 1).taskId + "\t" + (taskList.get(taskId - 1).selectedProcessorId + 1) + "\t" + taskList.get(taskId - 1).timeGap.startTime + "\t" + taskList.get(taskId - 1).timeGap.endTime);
		}
		//======================================================
		//====================================================
		//=====================END OF HEFT==== STARTING OF THE CHANGING COST

		//============PROCESSOR ID OF THE MINIMUM COST
		//Get the processor id with minimum cost
		GetMinCostProcessorIdLevel.getMinCostProcessorIdLevel(beta, taskList, processorsArray);
		System.out.println("maxcost\t\t\t\t\tmincost");
		for(Tasks task: taskList){
			System.out.println(task.maxCost + "\t\t\t" + task.minCost);
		}
		System.out.println();
		System.out.println("Rank upwards");
		//
		List<Map.Entry<Integer, Double>> taskDisCostList = GetDisCostTaskOrder.getDisCostTaskOrder(taskList);
		for(Map.Entry<Integer, Double> entry: taskDisCostList){
			System.out.println(entry.getKey() + "\t" + entry.getValue());
		}
		//
		ChangeFromMaxDisCost.changeFromMaxDisCost(maxTime, taskDisCostList, taskList, taskOrderList, taskEdgeHashMap, processorsArray);
		//
		//ChangeFromMinDisCost.changeFromMinDisCost(maxTime, taskDisCostList, taskList, taskOrderList, taskEdgeHashMap, processorsArray);
		System.out.println();
		System.out.println("CFMAX Schedule");
		for(Integer taskId: taskOrderList){
			System.out.println(taskList.get(taskId - 1).taskId + "\t" + (taskList.get(taskId - 1).selectedProcessorId + 1) + "\t" + taskList.get(taskId - 1).timeGap.startTime + "\t" + taskList.get(taskId - 1).timeGap.endTime);
		}

		ChangeFromMinDisCost.changeFromMinDisCost(maxTime, taskDisCostList, taskList, taskOrderList, taskEdgeHashMap, processorsArray);
		System.out.println();
		System.out.println("CFMIN Schedule");
		for(Integer taskId: taskOrderList){
			System.out.println(taskList.get(taskId - 1).taskId + "\t" + (taskList.get(taskId - 1).selectedProcessorId + 1) + "\t" + taskList.get(taskId - 1).timeGap.startTime + "\t" + taskList.get(taskId - 1).timeGap.endTime);
		}
	}
}
