package all.test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import xmu.lab.minmin.utils.CalculateMeanTournArround;
import xmu.lab.minmin.utils.CalculateThroughput;
import xmu.lab.minmin.utils.CreatetaskResourcesTable;
import xmu.lab.minmin.utils.FindTheMinimumTimeMap;
import xmu.lab.minmin.utils.GetMinimumTimeValue;
import xmu.lab.minmin.utils.GetRowandColsIndexAndTaskId;
import xmu.lab.minmin.utils.PrintMapForMinMin;
import xmu.lab.minmin.utils.PrintTaskResources;
import xmu.lab.minmin.utils.UpdateTotalTimeMap;

import a.xmu.lab.cfmaxmin.objects.Processors;
import a.xmu.lab.cfmaxmin.objects.Tasks;
import aaaa.xmu.lab.cfmaxmin.utils.CalcSumMaxCost;
import aaaa.xmu.lab.cfmaxmin.utils.CalcTaskMaxCost;
import aaaaa.xmu.lab.cfmaxmin.InputManager.InputManage;

public class MinMin {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		//========Initial input informations
		int maxTime = 5;         //Maximum Time
		int recourcesNum = 3;    //Number of resources
		int taskNums = 10;        //Number of Tasks
		double beta = 0.2;        //Betta in the equation

		//==== String Input files
		String computationCostPath = "computationCost.txt";
		String inputGraphPath = "inputGraph.txt";
		String processorInfor = "processorInfor.txt";
		//===creates objects for this calss
		//Initial schedule/initialize the schedule
		InputManage inputmanager = new InputManage();
		//List of tasks
		ArrayList<Tasks> mytasks = inputmanager.initTaskInfor(computationCostPath, inputGraphPath);
		//Map of Tasks and Edges
		HashMap<String, Integer> taskEdgeHashMap = inputmanager.initTaskEdge();
		//Processor array
		Processors[] myresources = new Processors[recourcesNum];
		myresources = inputmanager.initProcessorInfor(processorInfor, recourcesNum);


		//==============================================
		//=============================
		//Min-Min Starts from here

		Double[]readyTime=new Double[myresources.length];
		for(int i=0;i<myresources.length;i++){
			readyTime[i]=0.0;
		}
		List<List<Double>>TasksResources=CreatetaskResourcesTable.createtaskResourcestable(mytasks,myresources);
		//InitializeTotalTime(TasksResources,readyTime);//============Caused problem

		int count=1;
		Double totalCost=0.0;
		do{
			//System.out.println("========================");
			//System.out.println("Iteration number "+ count);
			//PrintTaskResources.printTaskResources(TasksResources);
			//Double totalCost=0.0;

			//Step 1. find the minimum number
			Map<Integer[], Double>map=FindTheMinimumTimeMap.findTheMinimumTimeMap(TasksResources);
			//PrintMapForMinMin.printMapForMinMin(map);

			//Step 2: retrieve all information from the map
			Integer[]tasksReourcesIndexTaskid=GetRowandColsIndexAndTaskId.getRowandColsIndexAndTaskId(map);
			Double minDouble=GetMinimumTimeValue.getMinimumTimeValue(map);
			int taskindex=tasksReourcesIndexTaskid[0];
			int resourceIndex=tasksReourcesIndexTaskid[1];
			int taskid=tasksReourcesIndexTaskid[2];//change in the map/table add the last column double of tasksid// not an issue
			//double taskid=(double)taskindex;
			//mask of cost
			double price=myresources[resourceIndex].fMax;
			Double exeutiont=mytasks.get(taskindex).computationCost.get(resourceIndex);
			double cost=price+exeutiont;
			//mask cost
			//System.out.println("Minimum Value: "+minDouble);
			//System.out.println("Task Index: "+taskindex);
			//System.out.println("Resource Id:"+resourceIndex);
			//System.out.println("Task Id: "+taskid);

			//3. Assign the tasks to the resources based on min-min
			//			System.out.println("Taskindex: "+taskindex);
			//			System.out.println("resources id:"+resourceIndex);
			//			System.out.println("Task id is:"+taskid);

			//mytasks.get(taskid).resourceId=resourceIndex;
			//System.out.println("resource id is "+resourceIndex);
			//taskindex must not be printed here but taskid //===========Caused problem
			//double costs=minDouble*mytasks.get(taskindex).minCostProcessorId;
			//System.out.println("The Taskid:"+taskid +" has been assigned to resource: "+resourceIndex+" Execution time: "+minDouble);
			mytasks.get(taskindex).selectedProcessorId=resourceIndex;//mytasks.get(taskid).setResourcesId(myresources.get(colIndex).getId);
			System.out.printf("The Task %d has been assigned to resource %d Completion time: %.4f cost: %.3f\n",taskid,resourceIndex,minDouble,cost);

			//step 4:update ready time array;
			Double oldReadyTime=readyTime[resourceIndex];//store the old value
			readyTime[resourceIndex]=minDouble;
			//System.out.println("The ready time array is: "+Arrays.toString(readyTime));//==================
			// step 5  update the task-vm with the current ready time
			UpdateTotalTimeMap.updateTotalTimeMap(resourceIndex,oldReadyTime,readyTime,TasksResources);
			//step 6: remove the row after the task has been assigned
			TasksResources.remove(taskindex);
			//System.out.println("This is the end of iteration "+count);
			//System.out.println("============================");
			totalCost+=cost;

			++count;
		}while(TasksResources.size()>0);
		System.out.println("totalCost cost "+totalCost);

		System.out.println("\n");
		//TurnArround
		CalculateMeanTournArround.CalculateAverageTournArround(mytasks);
		//Throughput
		CalculateThroughput.calculateThroughput(readyTime,taskNums);

	}



}
